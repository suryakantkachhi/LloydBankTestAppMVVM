//
//  LloydBankTestAppMVVMTests.swift
//  LloydBankTestAppMVVMTests
//
//  Created by JustMac on 14/02/22.
//

import XCTest
@testable import LloydBankTestAppMVVM

class FruitListViewModelTests: XCTestCase {
    
    var st: FruitListViewModel!
    var testAPIService: TestApiService!

    override func setUp() {
        super.setUp()
        testAPIService = TestApiService()
        st = FruitListViewModel(apiService: testAPIService)
    }
    
    override func tearDown() {
        st = nil
        testAPIService = nil
        super.tearDown()
    }
    
    func test_fetch_fruit() {
        // Given
        testAPIService.completeFruits = [Fruit]()

        // When
        st.apiService.fetchData(T: [Fruit].self) { success, model, error in
            // Assert
            XCTAssert(self.testAPIService!.isFetchFruitCalled)
        }
        
    }
    
    func test_fetch_fruit_fail() {
        
        // failed fetch with a certain failure
        let errorApi = APIError.permissionDenied
        
        // When
        st.apiService.fetchData(T: [Fruit].self) { success, model, error in
            // Assert
            self.testAPIService.fetchFail(error: error )
            // st should show predefined error
            XCTAssertEqual( self.st.alertMessage, errorApi.rawValue )
        }
    }

    func test_create_cell_view_model() {
        // Given
        let fruits = StubGenerator().stubFruits()
        testAPIService.completeFruits = fruits
        let expect = XCTestExpectation(description: "")
        st.reloadTableViewClosure = { () in
            expect.fulfill()
            // Number of cell in view model is equal to the number of Fruit
            XCTAssertEqual( self.st.numberOfCells, fruits.count )
        }
        
        self.st.initFetch()

        // XCTAssert reload closure triggered
        wait(for: [expect], timeout: 5.0)

    }
    
    func test_user_press_not_for_sale_fruit() {

        //Given a st with fetched Fruits
        let indexPath = IndexPath(row: 0, section: 0)
        goToFetchFruitFinished()
        let expect = XCTestExpectation(description: "")
        st.reloadTableViewClosure = { () in
            expect.fulfill()
            //When
            self.st.userPressed( at: indexPath )

            //Assert
            XCTAssertFalse( self.st.isAllowSegue )
            XCTAssertNil( self.st.selectedFruit )
        }
        self.st.initFetch()
        wait(for: [expect], timeout: 8.0)
    }
    
    func test_cell_view_model() {
        // Fruits for test cell vm
        let fruit = Fruit(genus: "", name: "", id: 23, family: "", order: "", nutritions: nil, imageUrl: "")
        let fruitWithoutName = Fruit(genus: "", name: nil, id: 23, family: "", order: "", nutritions: nil, imageUrl: "")
        let fruitWithoutImageUrl = Fruit(genus: "", name: "", id: 23, family: "", order: "", nutritions: nil, imageUrl: nil)

        // When creat cell view model
        let cellViewModel = st!.createCellViewModel(fruit: fruit)
        let cellViewModelWithoutName = st!.createCellViewModel(fruit: fruitWithoutName)
        let cellViewModelWithoutImageUrl = st!.createCellViewModel(fruit: fruitWithoutImageUrl)

        // Assert the correctness of display information
        XCTAssertEqual( fruit.name, cellViewModel.fruitTitleText )
        XCTAssertEqual( fruit.family, cellViewModel.fruitFamilyName )

        XCTAssertEqual(cellViewModel.fruitDescText, "\(fruit.name!) - \(fruit.genus!)" )
        XCTAssertEqual(cellViewModelWithoutName.fruitTitleText, AppConstants.na.rawValue )
        XCTAssertEqual(cellViewModelWithoutImageUrl.fruitImageUrl, AppConstants.fruitDefault.rawValue )
    }

}

//MARK: State control
extension FruitListViewModelTests {
    private func goToFetchFruitFinished() {
        testAPIService.completeFruits = StubGenerator().stubFruits()
        self.st.initFetch()
    }
}

class TestApiService: APIServiceProtocol {
    func fetchData<T>(T: T.Type, complete: @escaping (Bool, T, APIError?) -> ()) where T : Decodable, T : Encodable {
        let url = URL(string: AppUrls.getFruits.rawValue)!
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.global().async {
                if let data = data {
                    if let model = try? JSONDecoder().decode(T.self, from: data) {
                        print(model)
                        self.isFetchFruitCalled = true
                        self.completeFruits = model as! [Fruit]
                        complete(true, model, nil)
                    } else {
                        print(AppConstants.apiInvalidResponse.rawValue)
                    }
                } else if let error = error {
                    print(AppConstants.httpRequestFail.rawValue + error.localizedDescription)
                }
            }
        }
        task.resume()
    }
    
    var isFetchFruitCalled = false
    
    var completeFruits: [Fruit] = [Fruit]()
    var completeClosure: ((Bool, [Fruit], APIError?) -> ())!
    
    func fetchSuccess() {
        completeClosure( true, completeFruits, nil )
    }
    
    func fetchFail(error: APIError?) {
        completeClosure( false, completeFruits, error )
    }
    
}

class StubGenerator {
    func stubFruits() -> [Fruit] {
        let path = Bundle.main.path(forResource: "data", ofType: "json")!
        let data = try! Data(contentsOf: URL(fileURLWithPath: path))
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let fruits = try! decoder.decode([Fruit].self, from: data)
        return fruits
    }
}
