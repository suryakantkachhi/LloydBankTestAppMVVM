//
//  LloydBankTestAppMVVMTests.swift
//  LloydBankTestAppMVVMTests
//
//  Created by JustMac on 14/02/22.
//

import XCTest
@testable import LloydBankTestAppMVVM

class PhotoListViewModelTests: XCTestCase {
    
    var st: PhotoListViewModel!
    var mockAPIService: MockApiService!

    override func setUp() {
        super.setUp()
        mockAPIService = MockApiService()
        st = PhotoListViewModel(apiService: mockAPIService)
    }
    
    override func tearDown() {
        st = nil
        mockAPIService = nil
        super.tearDown()
    }
    
    func test_fetch_photo() {
        // Given
        mockAPIService.completePhotos = [Photo]()

        // When
        st.initFetch()
    
        // Assert
        XCTAssert(mockAPIService!.isFetchPhotoCalled)
    }
    
    func test_fetch_photo_fail() {
        
        // failed fetch with a certain failure
        let error = AppAPIError.permissionDenied
        
        // When
        st.initFetch()
        
        mockAPIService.fetchFail(error: error )
        
        // st should show predefined error message
        XCTAssertEqual( st.alertMessage, error.rawValue )
        
    }
    
    func test_create_cell_view_model() {
        // Given
        let photos = StubGenerator().stubPhotos()
        mockAPIService.completePhotos = photos
        let expect = XCTestExpectation(description: "")
        st.reloadTableViewClosure = { () in
            expect.fulfill()
        }
        
        // When
        st.initFetch()
        mockAPIService.fetchSuccess()
        
        // Number of cell in view model is equal to the number of photo
        XCTAssertEqual( st.numberOfCells, photos.count )
        
        // XCTAssert reload closure triggered
        wait(for: [expect], timeout: 1.0)
        
    }
    
    func test_user_press_for_sale_item() {
        
        //Given a st with fetched photos
        let indexPath = IndexPath(row: 0, section: 0)
        goToFetchPhotoFinished()

        //When
        st.userPressed( at: indexPath )
        
        //Assert
        XCTAssertTrue( st.isAllowSegue )
        XCTAssertNotNil( st.selectedPhoto )
        
    }
    
    func test_user_press_not_for_sale_item() {
        
        //Given a st with fetched photos
        let indexPath = IndexPath(row: 1, section: 0)
        goToFetchPhotoFinished()
        
        let expect = XCTestExpectation(description: "Alert message is shown")
        st.showAlertClosure = { [weak st] in
            expect.fulfill()
            XCTAssertEqual(st!.alertMessage, "This item is not for sale")
        }
        
        //When
        st.userPressed( at: indexPath )
        
        //Assert
        XCTAssertFalse( st.isAllowSegue )
        XCTAssertNil( st.selectedPhoto )
        
        wait(for: [expect], timeout: 1.0)
    }
    
    func test_cell_view_model() {
        // photos for test cell vm
        let today = Date()
        let photo = Photo(id: 1, for_sale: true, name: "name", camera: "camra", description: "dis", created_at: today, image_url: "http://google.com")
        let photoWithoutCarmera = Photo(id: 1, for_sale: true, name: "name", camera: nil, description: "dis", created_at: today, image_url: "http://google.com")
        let photoWithoutDesc = Photo(id: 1, for_sale: true, name: "name", camera: "camra", description: nil, created_at: today, image_url: "http://google.com")
        let photoWithouCameraAndDesc = Photo(id: 1, for_sale: true, name: "name", camera: nil, description: nil, created_at: today, image_url: "http://google.com")
        
        // When creat cell view model
        let cellViewModel = st!.createCellViewModel( photo: photo )
        let cellViewModelWithoutCamera = st!.createCellViewModel( photo: photoWithoutCarmera )
        let cellViewModelWithoutDesc = st!.createCellViewModel( photo: photoWithoutDesc )
        let cellViewModelWithoutCameraAndDesc = st!.createCellViewModel( photo: photoWithouCameraAndDesc )
        
        // Assert the correctness of display information
        XCTAssertEqual( photo.name, cellViewModel.titleText )
        XCTAssertEqual( photo.image_url, cellViewModel.imageUrl )
        
        XCTAssertEqual(cellViewModel.descText, "\(photo.camera!) - \(photo.description!)" )
        XCTAssertEqual(cellViewModelWithoutDesc.descText, photoWithoutDesc.camera! )
        XCTAssertEqual(cellViewModelWithoutCamera.descText, photoWithoutCarmera.description! )
        XCTAssertEqual(cellViewModelWithoutCameraAndDesc.descText, "" )
    }

}

//MARK: State control
extension PhotoListViewModelTests {
    private func goToFetchPhotoFinished() {
        mockAPIService.completePhotos = StubGenerator().stubPhotos()
        st.initFetch()
        mockAPIService.fetchSuccess()
    }
}

class MockApiService: AppAPIServiceProtocol {
    
    var isFetchPhotoCalled = false
    
    var completePhotos: [Photo] = [Photo]()
    var completeClosure: ((Bool, [Photo], AppAPIError?) -> ())!
    
    func fetchPhoto(complete: @escaping (Bool, [Photo], AppAPIError?) -> ()) {
        isFetchPhotoCalled = true
        completeClosure = complete
        
    }
    
    func fetchSuccess() {
        completeClosure( true, completePhotos, nil )
    }
    
    func fetchFail(error: AppAPIError?) {
        completeClosure( false, completePhotos, error )
    }
    
}

class StubGenerator {
    func stubPhotos() -> [Photo] {
        let path = Bundle.main.path(forResource: "data", ofType: "json")!
        let data = try! Data(contentsOf: URL(fileURLWithPath: path))
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let photos = try! decoder.decode(Photos.self, from: data)
        return photos.photos
    }
}
