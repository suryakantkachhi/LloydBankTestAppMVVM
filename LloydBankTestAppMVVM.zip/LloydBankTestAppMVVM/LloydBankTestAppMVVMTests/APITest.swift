//
//  APITest.swift
//  LloydBankTestAppMVVMTests
//
//  Created by JustMac on 14/02/22.
//

import XCTest
@testable import LloydBankTestAppMVVM

class APIServiceTests: XCTestCase {
    
    var st: AppAPIService?
    
    override func setUp() {
        super.setUp()
        st = AppAPIService()
    }

    override func tearDown() {
        st = nil
        super.tearDown()
    }

    func test_fetch_pictures() {

        // api service
        let sut = self.st!

        // fetch
        let expect = XCTestExpectation(description: "CALLBACK")

        sut.fetchPhoto(complete: { (success, photos, error) in
            expect.fulfill()
            XCTAssertEqual( photos.count, 8)
            for photo in photos {
                XCTAssertNotNil(photo.id)
            }
            
        })

        wait(for: [expect], timeout: 3.1)
    }
    
}
