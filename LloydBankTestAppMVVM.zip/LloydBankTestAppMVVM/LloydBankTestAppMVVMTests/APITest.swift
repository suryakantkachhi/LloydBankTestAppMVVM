//
//  APITest.swift
//  LloydBankTestAppMVVMTests
//
//  Created by JustMac on 14/02/22.
//

import XCTest
@testable import LloydBankTestAppMVVM

class APIServiceTests: XCTestCase {
    
    var st: APIService?
    
    override func setUp() {
        super.setUp()
        st = APIService()
    }

    override func tearDown() {
        st = nil
        super.tearDown()
    }

    func test_fetch_pictures() {

        // api service
        let sut = self.st!

        // fetch
        let expect = XCTestExpectation(description: "CALLBACK")

        sut.fetchData(T: [Fruit].self, complete: { (success, fruits, error) in
            expect.fulfill()
            XCTAssertEqual( fruits.count, 8)
            for fruit in fruits {
                XCTAssertNotNil(fruit.id)
            }
            
        })

        wait(for: [expect], timeout: 3.1)
    }
    
}
