//
//  Util.swift
//  LloydBankTestAppMVVM
//
//  Created by JustMac on 21/02/22.
//

import Foundation
import UIKit

enum AppUrls: String {
    case getFruits = "https://www.fruityvice.com/api/fruit/all"
}

enum AppConstants: String {
    case portfolioName = "Fruits List"
    case apiInvalidResponse = "Invalid Response"
    case httpRequestFail = "Request Failed"
    case na = "NA"
    case notForSale = "This fruit is not available"
    case actionText = "Ok"
    case alertTitle = "Alert"
    case fatalError = "Cell not found"
    case fruitDefault = "fruit_icon"
    case seprator = " - "
}

extension UIImage {
    static var fruit_icon : UIImage? {
        return UIImage(named: AppConstants.fruitDefault.rawValue)
    }
}
