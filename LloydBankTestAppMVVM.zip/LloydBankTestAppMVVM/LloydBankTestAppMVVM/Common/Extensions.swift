//
//  Extensions.swift
//  LloydBankTestAppMVVM
//
//  Created by JustMac on 21/02/22.
//

import Foundation
import UIKit

protocol ReusableView {
    static var reuseIdentifier: String { get }
}

extension ReusableView {
    static var reuseIdentifier: String {
        return String(describing: self)
    }
}

extension UITableViewCell: ReusableView {}

extension UIViewController {
    // simple UI alert
    func showAlert( _ message: String ) {
        let alert = UIAlertController(title: AppConstants.alertTitle.rawValue, message: message, preferredStyle: .alert)
        alert.addAction( UIAlertAction(title: AppConstants.actionText.rawValue, style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}
