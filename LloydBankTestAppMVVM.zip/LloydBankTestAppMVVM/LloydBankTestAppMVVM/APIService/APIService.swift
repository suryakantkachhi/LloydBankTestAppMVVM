//
//  APIService.swift
//  LloydBankTestAppMVVM
//
//  Created by JustMac on 14/02/22.
//

import Foundation

enum APIError: String, Error {
    case noNetwork = "NoNetwork"
    case serverOverload = "ServerIsOverloaded"
    case permissionDenied = "NoPermission"
}

protocol APIServiceProtocol {
    func fetchData<T>( T: T.Type, complete: @escaping ( _ success: Bool, _ model: T, _ error: APIError? )->() ) where T:Codable
}

class APIService: APIServiceProtocol {
    // fetching
    func fetchData<T>( T: T.Type, complete: @escaping ( _ success: Bool, _ model: T, _ error: APIError? )->() ) where T:Codable {
        let url = URL(string: AppUrls.getFruits.rawValue)!
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.global().async {
                if let data = data {
                    if let model = try? JSONDecoder().decode(T.self, from: data) {
                        print(model)
                        complete(true, model, nil)
                    } else {
                        print(AppConstants.apiInvalidResponse.rawValue)
                    }
                } else if let error = error {
                    print(AppConstants.httpRequestFail.rawValue + error.localizedDescription)
                }
            }
        }
        task.resume()
    }
    
    
    
}
