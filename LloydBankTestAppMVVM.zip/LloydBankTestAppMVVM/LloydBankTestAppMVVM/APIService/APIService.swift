//
//  APIService.swift
//  LloydBankTestAppMVVM
//
//  Created by JustMac on 14/02/22.
//

import Foundation

enum AppAPIError: String, Error {
    case noNetwork = "NoNetwork"
    case serverOverload = "ServerIsOverloaded"
    case permissionDenied = "no permission"
}

protocol AppAPIServiceProtocol {
    func fetchPhoto( complete: @escaping ( _ success: Bool, _ photos: [Photo], _ error: AppAPIError? )->() )
}

class AppAPIService: AppAPIServiceProtocol {
    // fetching
    func fetchPhoto( complete: @escaping ( _ success: Bool, _ photos: [Photo], _ error: AppAPIError? )->() ) {
        DispatchQueue.global().async {
            sleep(3)
            let path = Bundle.main.path(forResource: "data", ofType: "json")!
            let data = try! Data(contentsOf: URL(fileURLWithPath: path))
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let photos = try! decoder.decode(Photos.self, from: data)
            complete( true, photos.photos, nil )
        }
    }
    
    
    
}
