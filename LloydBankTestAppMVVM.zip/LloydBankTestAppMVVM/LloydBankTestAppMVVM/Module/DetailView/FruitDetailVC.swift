//
//  FruitDetailViewController.swift
//  LloydBankTestAppMVVM
//
//  Created by JustMac on 14/02/22.
//

import UIKit

class FruitDetailVC: UIViewController {

    // image 
    var image: UIImage?
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let name = image {
            imageView.image = name
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
