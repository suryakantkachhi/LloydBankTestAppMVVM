//
//  FruitListVC.swift
//  LloydBankTestAppMVVM
//
//  Created by JustMac on 14/02/22.
//

import UIKit

class FruitListVC: UIViewController {
    // outlets for view
    // collection of list
    @IBOutlet weak var tableView: UITableView!
    // loading indicator
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    // viewmodel ownership
    var viewModel: FruitListViewModel = {
        return FruitListViewModel()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Init the static view
        initView()
        
        // init view model
        initVM()
        
    }
    
    func initView() {
        self.navigationItem.title = AppConstants.portfolioName.rawValue
        
        tableView.estimatedRowHeight = 150
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    func initVM() {
        
        // Naive binding
        // UI Alert, also can be added as an extension of UIViewController
        viewModel.showAlertClosure = { [weak self] () in
            DispatchQueue.main.async {
                if let message = self?.viewModel.alertMessage {
                    self?.showAlert( message )
                }
            }
        }
        // change in loading indicator
        viewModel.updateLoadingStatus = { [weak self] () in
            DispatchQueue.main.async {
                let isLoading = self?.viewModel.isLoading ?? false
                if isLoading {
                    self?.activityIndicator.startAnimating()
                    UIView.animate(withDuration: 0.2, animations: {
                        self?.tableView.alpha = 0.0
                    })
                }else {
                    self?.activityIndicator.stopAnimating()
                    UIView.animate(withDuration: 0.2, animations: {
                        self?.tableView.alpha = 1.0
                    })
                }
            }
        }
        // reload the table when data is assigned
        viewModel.reloadTableViewClosure = { [weak self] () in
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
        // initial call while loading view
        viewModel.initFetch()

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

extension FruitListVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // nib cell init, also can be init in UITableViewCell extension
        guard let cell = tableView.dequeueReusableCell(withIdentifier: FruitListTableViewCell.reuseIdentifier, for: indexPath) as? FruitListTableViewCell else {
            fatalError(AppConstants.fatalError.rawValue)
        }
        
        let cellVM = viewModel.getCellViewModel( at: indexPath )
        cell.fruitListCellViewModel = cellVM
        
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfCells
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150.0
    }
    
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        
        self.viewModel.userPressed(at: indexPath)
        if viewModel.isAllowSegue {
            return indexPath
        }else {
            return nil
        }
    }

}

extension FruitListVC {
    // preparing UI navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? FruitDetailVC,
          let _ = viewModel.selectedFruit {
            vc.image = UIImage.fruit_icon
        }
    }
}

class FruitListTableViewCell: UITableViewCell {
    @IBOutlet weak var fruitImageView: UIImageView!
    @IBOutlet weak var fruitFamilyLabel: UILabel!
    @IBOutlet weak var fruitDescriptionLabel: UILabel!
    @IBOutlet weak var fruitNameLabel: UILabel!
    @IBOutlet weak var descContainerHeightConstraint: NSLayoutConstraint!
    var fruitListCellViewModel : FruitListCellViewModel? {
        didSet {
            // updating UI
            fruitNameLabel.text = fruitListCellViewModel?.fruitTitleText
            fruitDescriptionLabel.text = fruitListCellViewModel?.fruitDescText
            fruitImageView?.image = UIImage(named: fruitListCellViewModel?.fruitImageUrl ?? AppConstants.fruitDefault.rawValue)
            fruitFamilyLabel.text = fruitListCellViewModel?.fruitFamilyName
        }
    }
}
