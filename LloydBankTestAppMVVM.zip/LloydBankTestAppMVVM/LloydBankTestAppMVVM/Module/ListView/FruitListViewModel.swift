//
//  FruitListViewModel.swift
//  LloydBankTestAppMVVM
//
//  Created by JustMac on 14/02/22.
//

import Foundation

class FruitListViewModel {
    
    let apiService: APIServiceProtocol

    private var fruits: [Fruit] = [Fruit]()
    var reloadTableViewClosure: (()->())?
    var showAlertClosure: (()->())?
    var updateLoadingStatus: (()->())?
    
    private var cellViewModels: [FruitListCellViewModel] = [FruitListCellViewModel]() {
        didSet {
            self.reloadTableViewClosure?()
        }
    }

    var isLoading: Bool = false {
        didSet {
            self.updateLoadingStatus?()
        }
    }
    
    var alertMessage: String? {
        didSet {
            self.showAlertClosure?()
        }
    }
    
    var numberOfCells: Int {
        return cellViewModels.count
    }
    
    var isAllowSegue: Bool = false
    
    var selectedFruit: Fruit?

    init( apiService: APIServiceProtocol = APIService()) {
        self.apiService = apiService
    }
    
    func initFetch() {
        self.isLoading = true
        apiService.fetchData(T: [Fruit].self) { [weak self] (success, model, error) in
            self?.isLoading = false
            if let error = error {
                self?.alertMessage = error.rawValue
            } else {
                self?.processFetchedFruits(fruits: model)
            }
        }
    }
    
    func getCellViewModel( at indexPath: IndexPath ) -> FruitListCellViewModel {
        return cellViewModels[indexPath.row]
    }
    
    func createCellViewModel( fruit: Fruit ) -> FruitListCellViewModel {

        //Wrap a description
        var descTextContainer: [String] = [String]()
        if let name = fruit.name {
            descTextContainer.append(name)
        }
        if let description = fruit.genus {
            descTextContainer.append( description )
        }
        let desc = descTextContainer.joined(separator: AppConstants.seprator.rawValue)
        
        return FruitListCellViewModel( fruitTitleText: fruit.name ?? AppConstants.na.rawValue,
                                       fruitDescText: desc,
                                       fruitImageUrl: fruit.imageUrl ?? AppConstants.fruitDefault.rawValue,
                                       fruitFamilyName: fruit.family )
    }
    
    private func processFetchedFruits( fruits: [Fruit] ) {
        self.fruits = fruits // Cache
        var vms = [FruitListCellViewModel]()
        for Fruit in fruits {
            vms.append( createCellViewModel(fruit: Fruit) )
        }
        self.cellViewModels = vms
    }
    
}

extension FruitListViewModel {
    func userPressed( at indexPath: IndexPath ){
        let fruit = self.fruits[indexPath.row]
        // Just temporary case
        if fruit.id > 50 {
            self.isAllowSegue = true
            self.selectedFruit = fruit
        }else {
            self.isAllowSegue = false
            self.selectedFruit = nil
            self.alertMessage = AppConstants.notForSale.rawValue
        }
        
    }
}

struct FruitListCellViewModel {
    let fruitTitleText: String
    let fruitDescText: String
    let fruitImageUrl: String
    let fruitFamilyName: String
}
