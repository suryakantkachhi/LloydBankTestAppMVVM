//
//  Photo.swift
//  LloydBankTestAppMVVM
//
//  Created by JustMac on 14/02/22.
//

import Foundation

struct Photos: Codable {
    // collection of pictures
    let photos: [Photo]
}

struct Photo: Codable {
    let id: Int
    let for_sale: Bool
    let name: String
    
    let camera: String?
    let description: String?
    let created_at: Date
    // image public url
    let image_url: String
}
